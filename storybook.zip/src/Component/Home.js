import React, { Component } from 'react';
class Home extends Component {
    state = {  } 
    render() { 
        return (
            <h1 className='homePage'>Welcome to the Storybook</h1>
        );
    }
}
 
export default Home;
