import React, { Component } from 'react';
class Contactus extends Component {
    state = {}
    render() {
        return (
            <div className='servicesPage'>
                <h3>Email:abc@gmail.com </h3>
                
            </div>
        );
    }
}

export default Contactus;