import React, { Component } from 'react';
class About extends Component {
    state = {}
    render() {
        return (
            <div className='aboutPage'>
                 <h3>This is an About Page</h3>
            </div>
        );
    }
}

export default About;