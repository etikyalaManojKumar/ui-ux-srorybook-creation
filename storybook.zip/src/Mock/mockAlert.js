export const mockAlert = [
    {
        name: 'primary',
        width: '300px',
        height: '40px',
        margin_bottom: '15px',
        backgroundColor: '#81ecec'
    },
    {
        name: 'secondary',
        width: '300px',
        height: '40px',
        margin_bottom: '15px',
        backgroundColor: '#fab1a0'
    },
]