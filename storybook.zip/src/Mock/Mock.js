
export const pageDetails = [
    {
        id: 1,
        name: 'Home',
        path: '/',
    },
    {
        id: 2,
        name: 'About',
        path: '/about',        
    },
    {
        id: 3,
        name: 'Contactus',
        path: '/contactus',
    },
]