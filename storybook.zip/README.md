# Getting Started with Create Story Book 

This project was bootstrapped with UX framework

## Available Scripts

In the project directory, you can run:

### `local HTML`

Runs the app in the browser.\
## Learn More

You can learn more 